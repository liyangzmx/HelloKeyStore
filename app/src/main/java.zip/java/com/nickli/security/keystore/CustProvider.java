package com.nickli.security.keystore;

import java.security.Provider;
import java.security.Security;

public class CustProvider extends Provider {
    private static final String PACKAGE_NAME = "com.nickli.security.keystore";
    private static final String PROVIDER_NAME = "Cust Provider";

    /**
     * Constructs a provider with the specified name, version number,
     * and information.
     *
     * @param name    the provider name.
     * @param version the provider version number.
     * @param info    a description of the provider and its services.
     */
    protected CustProvider() {
        super(PROVIDER_NAME, 1.0d, "Cust keystore security provider");
        System.out.println("jms: CustProvider()");

        put("Signature.NONEwithECDSA", PACKAGE_NAME + ".CustSignatureSpi");
        put("Alg.Alias.Signature.NONEwithECDSA", "NONEwithECDSA");
    }

    public static void installAsDefault() {
        Provider[] providers = Security.getProviders("SSLContext.TLS");
//        if (providers != null && "AndroidOpenSSL".equals(providers[0].getName())) {
//            Security.addProvider(new CustProvider());
//            System.out.println("jms: add sky keystore after android openssl.");
//            return;
//        }
        int ret = Security.insertProviderAt(new CustProvider(), 1);
        System.out.println("jms: add sky keystore at first. ret: " + ret);
    }

    public static void install() {
        Security.addProvider(new CustProvider());
        System.out.println("jms: add sky keystore default.");
    }
}
