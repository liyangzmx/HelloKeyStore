package com.nickli.security.keystore;

import android.security.keystore.KeyProperties;
import android.util.Log;

import java.math.BigInteger;
import java.security.interfaces.ECPrivateKey;
import java.security.spec.ECParameterSpec;

public class CustECPrivateKey implements ECPrivateKey {
    private ECParameterSpec spec;
    private String alias;
    private String format;

    public static void printStackTrace() {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();

        for (StackTraceElement element : stackTraceElements) {
            String className = element.getClassName();
            String methodName = element.getMethodName();
            String fileName = element.getFileName();
            int lineNumber = element.getLineNumber();

            String stackTrace = String.format("at %s.%s(%s:%d)", className, methodName, fileName, lineNumber);

            // 打印到日志
            Log.d("jms", stackTrace);

            // 打印到控制台
            System.out.println(stackTrace);
        }
    }

    public CustECPrivateKey(String alias, String format, ECParameterSpec spec) {
        this.alias = alias;
        this.spec = spec;
        this.format = format;
    }

    @Override
    public BigInteger getS() {
        return null;
    }

    public String getAlias() {
        return alias;
    }

    @Override
    public String getAlgorithm() {
        System.out.println("jms: getAlgorithm: EC");
        return KeyProperties.KEY_ALGORITHM_EC;
    }

    @Override
    public String getFormat() {
        System.out.println("jms: getFormat: " + format);
        return format;
    }

    @Override
    public byte[] getEncoded() {
        System.out.println("jms: getEncoded: null");
        return null;
    }

    @Override
    public ECParameterSpec getParams() {
        System.out.println("jms: getParams: " + spec);
        return spec;
    }
}
