package com.nickli;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.nickli.hellokeystore.R;
import com.nickli.security.netty.NettyClient;
import com.nickli.security.netty.NettyServer;
import com.nickli.security.utils.ECCKeyUtil;

import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.util.io.pem.PemObject;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Base64;

public class MainActivity extends AppCompatActivity {
//    private ECCKeyUtil mECCKeyUtil = new ECCKeyUtil();
    HandlerThread sendThread = new HandlerThread("Sender");
    HandlerThread recvThread = new HandlerThread("Receiver");
    Looper sendLooper = null;
    Looper recvLooper = null;
    Handler sendHandler = null;
    Handler recvHander = null;
    NettyClient nettyClient = new NettyClient();
    NettyServer nettyServer = new NettyServer();
    KeyStore.PrivateKeyEntry mPrivateKeyEntry;

    private ECCKeyUtil mECCKeyUtil = new ECCKeyUtil();
    private static final String ANDROID_KEYSTORE_PROVIDER = "AndroidKeyStore";
    private static final String CLIENT_KEY_ALIAS = "client_key_alias";
    private static final String SERVER_KEY_ALIAS = "server_key_alias";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (true) {
            sendThread.start();
            sendLooper = sendThread.getLooper();
            sendHandler = new Handler(sendLooper);
            sendHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(100);
                        nettyClient.send();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });

        mECCKeyUtil.deleteKey(CLIENT_KEY_ALIAS);
        mECCKeyUtil.deleteKey(SERVER_KEY_ALIAS);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                mECCKeyUtil.genKeyPair(CLIENT_KEY_ALIAS);
                mECCKeyUtil.genKeyPair(SERVER_KEY_ALIAS);
            }
            recvThread.start();
            recvLooper = recvThread.getLooper();
            recvHander = new Handler(recvLooper);
            recvHander.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        nettyServer.recv();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
        }

        if (false) {
            mECCKeyUtil.deleteKey(CLIENT_KEY_ALIAS);
            mECCKeyUtil.deleteKey(SERVER_KEY_ALIAS);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                mECCKeyUtil.genKeyPair(CLIENT_KEY_ALIAS);
                mECCKeyUtil.genKeyPair(SERVER_KEY_ALIAS);
            }

            String clientAlias = CLIENT_KEY_ALIAS;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                mECCKeyUtil.genKeyPairDefault();
            }
            String serverEphemeralString = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE3JZcof/4ONKBqHyQ0g+2i36Ot0BwXZPMZor0xDguZQL711xfWR6y7TjJ5u3TgdEVn9iSKhrqEf8mrtr5ZpfrUw==";
            byte[] serverEphemeralPublicKey = new byte[0];
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                serverEphemeralPublicKey = Base64.getDecoder().decode(serverEphemeralString);
            }
            String inputStr = "Hello ECC";
            byte[] input = inputStr.getBytes(StandardCharsets.UTF_8);

            // Encrypt Data
            byte[] secret = mECCKeyUtil.ECDH(clientAlias, serverEphemeralPublicKey);
            ByteArrayOutputStream ivout = new ByteArrayOutputStream();
            byte[] encryptedData = mECCKeyUtil.encrypt(secret, input, ivout);
            // Sign Encryt Data
            byte[] signature = mECCKeyUtil.sign(clientAlias, encryptedData);

            // Verify Encrypted Data
            boolean verifyResult = mECCKeyUtil.verify(clientAlias, encryptedData, signature);
            System.out.println("verifyResult: " + verifyResult);
            // Decrypt Data
            byte[] decryptedData = mECCKeyUtil.decrypt(secret, encryptedData, ivout.toByteArray());
            System.out.println("Decyrpted data: " + new String(decryptedData));

            PKCS10CertificationRequest csr = mECCKeyUtil.generateCSR(clientAlias);
            System.out.println("CSR Subject: " + csr.getSubject().toString());
            byte[] csrBytes = new byte[0];
            try {
                csrBytes = csr.getEncoded();
            } catch (IOException e) {
                e.printStackTrace();
            }
            PemObject pemObject = new PemObject("CERTIFICATE REQUEST", csrBytes);
            StringWriter stringWriter = new StringWriter();
            try (JcaPEMWriter pemWriter = new JcaPEMWriter(stringWriter)) {
                pemWriter.writeObject(pemObject);
            } catch (IOException e) {
                e.printStackTrace();
            }
            String pemStr = stringWriter.toString();
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream("/sdcard/Download/test.csr");
                fos.write(pemStr.getBytes());
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            final String CA_KEY_ALIAS = "ca_alias";
            mECCKeyUtil.deleteKey(CA_KEY_ALIAS);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                mECCKeyUtil.genKeyPair(CA_KEY_ALIAS);
            }

            X509Certificate certificate = mECCKeyUtil.signCSR(CA_KEY_ALIAS, csr);
            System.out.println("Certificate: " + certificate.toString());
        }
    }
}