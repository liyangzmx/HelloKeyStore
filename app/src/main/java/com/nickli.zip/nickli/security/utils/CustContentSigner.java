package com.nickli.security.utils;

import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.X509ObjectIdentifiers;
import org.bouncycastle.operator.ContentSigner;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;

class CustContentSigner implements ContentSigner {
    private final ByteArrayOutputStream outputStream;
    private final Signature finalSignature;
    private final PrivateKey privateKey;
    private final boolean mIsRSA;

    public CustContentSigner(PrivateKey privateKey, Signature finalSignature, boolean isRSA) {
        this.outputStream = new ByteArrayOutputStream();
        this.finalSignature = finalSignature;
        this.privateKey = privateKey;
        mIsRSA = isRSA;
    }

    @Override
    public AlgorithmIdentifier getAlgorithmIdentifier() {
        if (mIsRSA)
            return new AlgorithmIdentifier(
                    // 1.2.840.113549.1.1.11 is SHA256withRSA
                    new ASN1ObjectIdentifier("1.2.840.113549.1.1.11")
            );
        else
            return new AlgorithmIdentifier(
                    // 1.2.840.10045.4.3.2 is SHA256withECDSA
                    new ASN1ObjectIdentifier("1.2.840.10045.4.3.2")
            );
    }

    @Override
    public OutputStream getOutputStream() {
        return outputStream;
    }

    @Override
    public byte[] getSignature() {
        try {
            assert finalSignature != null;
            finalSignature.initSign(privateKey);
            System.out.println("outputStream len: " + outputStream.size());
            finalSignature.update(outputStream.toByteArray());
            return finalSignature.sign();
        } catch (SignatureException | InvalidKeyException e) {
            e.printStackTrace();
        }
        return null;
    }
}
